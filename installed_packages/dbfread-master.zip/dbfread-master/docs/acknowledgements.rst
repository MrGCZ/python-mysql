Acknowledgements
================

The code page table is based on the one in Ethan Furman's `dbf
<http://pypi.python.org/pypi/dbf>`_ package.
