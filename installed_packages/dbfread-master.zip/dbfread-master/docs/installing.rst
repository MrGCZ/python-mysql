Installing dbfread
==================

Requirements
------------

Requires Python 3.2 or 2.7.  ``dbfread`` is a pure Python module, so
doesn't depend on any packages outside the standard library.


Installing
----------

::

  pip install dbfread
